import random

def number_guessing_game():
    """
    1～100の間の数字を当てるゲーム
    """
    # 1～100の間のランダムな数字を生成
    secret_number = random.randint(1, 100)
    attempts = 0
    
    print("=" * 50)
    print("数当てゲームへようこそ！")
    print("1～100の間の数字を当ててください。")
    print("=" * 50)
    
    while True:
        try:
            # ユーザーの入力を受け取る
            guess = int(input("\nあなたの予想を入力してください: "))
            attempts += 1
            
            # 入力値の範囲チェック
            if guess < 1 or guess > 100:
                print("⚠️  1～100の間の数字を入力してください。")
                attempts -= 1  # 範囲外の入力は試行回数にカウントしない
                continue
            
            # ユーザーの入力と正解を比較してヒントを表示
            if guess == secret_number:
                # 正解時の処理：試行回数を表示してゲーム終了
                print("\n" + "=" * 50)
                print(f"🎉 おめでとうございます！正解です！")
                print(f"答えは {secret_number} でした。")
                print(f"試行回数: {attempts} 回")
                print("=" * 50)
                break
            elif guess < secret_number:
                # 入力が正解より小さい場合のヒント
                print(f"📈 もっと大きい数字です！ (試行回数: {attempts})")
            else:
                # 入力が正解より大きい場合のヒント
                print(f"📉 もっと小さい数字です！ (試行回数: {attempts})")
                
        except ValueError:
            print("⚠️  数字を入力してください。")
        except KeyboardInterrupt:
            print("\n\nゲームを終了します。")
            break
        except Exception as e:
            print(f"⚠️  エラーが発生しました: {e}")

if __name__ == "__main__":
    number_guessing_game()

